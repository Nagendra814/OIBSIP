// script.js
document.getElementById('convertBtn').addEventListener('click', function() {
    // Get the input value and selected unit
    const tempInput = parseFloat(document.getElementById('tempInput').value);
    const unit = document.getElementById('unitSelect').value;
    let result = '';

    // Validate input
    if (isNaN(tempInput)) {
        result = 'Please enter a valid number.';
    } else {
        // Perform conversion based on selected unit
        switch (unit) {
            case 'celsius':
                result = `Fahrenheit: ${(tempInput * 9/5) + 32}°F\nKelvin: ${tempInput + 273.15}K`;
                break;
            case 'fahrenheit':
                result = `Celsius: ${(tempInput - 32) * 5/9}°C\nKelvin: ${((tempInput - 32) * 5/9) + 273.15}K`;
                break;
            case 'kelvin':
                result = `Celsius: ${tempInput - 273.15}°C\nFahrenheit: ${((tempInput - 273.15) * 9/5) + 32}°F`;
                break;
        }
    }

    // Display the result
    document.getElementById('output').innerText = result;
});
